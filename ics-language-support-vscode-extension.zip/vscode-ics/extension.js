// ICS Language Support (VS Code extension)
// - Syntax highlighting via TextMate grammar
// - Command to start/stop the ICS solver in "-server" mode

const vscode = require('vscode');
const cp = require('child_process');

/** @type {import('child_process').ChildProcess | undefined} */
let serverProcess;
/** @type {vscode.OutputChannel | undefined} */
let output;
/** @type {vscode.StatusBarItem | undefined} */
let status;
/** @type {number | undefined} */
let currentPort;

function getCwd(cfg) {
  const configured = cfg.get('server.cwd');
  if (configured && typeof configured === 'string') {
    return configured;
  }
  const wf = vscode.workspace.workspaceFolders;
  if (wf && wf.length > 0) {
    return wf[0].uri.fsPath;
  }
  return undefined;
}

function ensureUI(context) {
  if (!output) {
    output = vscode.window.createOutputChannel('ICS Server');
    context.subscriptions.push(output);
  }
  if (!status) {
    status = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Left, 100);
    status.text = 'ICS: Server stopped';
    status.tooltip = 'ICS server is not running';
    status.command = 'ics.startServer';
    status.show();
    context.subscriptions.push(status);
  }
}

function setStatusRunning(port) {
  if (!status) return;
  status.text = `ICS: Server ${port}`;
  status.tooltip = `ICS server running on port ${port}. Click to stop.`;
  status.command = 'ics.stopServer';
}

function setStatusStopped() {
  if (!status) return;
  status.text = 'ICS: Server stopped';
  status.tooltip = 'ICS server is not running. Click to start.';
  status.command = 'ics.startServer';
}

/**
 * @param {vscode.ExtensionContext} context
 * @param {number | undefined} portOverride
 */
async function startServer(context, portOverride) {
  ensureUI(context);

  if (serverProcess && !serverProcess.killed) {
    vscode.window.showInformationMessage(`ICS server is already running on port ${currentPort ?? '(unknown)'}.`);
    output?.show(true);
    return;
  }

  const cfg = vscode.workspace.getConfiguration('ics');
  const exe = cfg.get('executablePath');
  if (!exe || typeof exe !== 'string' || exe.trim() === '') {
    vscode.window.showErrorMessage('ICS executable path is empty. Set ics.executablePath in Settings.');
    return;
  }

  let port = portOverride;
  if (typeof port !== 'number') {
    const configuredPort = cfg.get('server.port');
    port = typeof configuredPort === 'number' ? configuredPort : 8123;
  }

  if (!Number.isInteger(port) || port < 1 || port > 65535) {
    vscode.window.showErrorMessage(`Invalid ICS server port: ${port}. Set ics.server.port (1-65535).`);
    return;
  }

  const extraArgs = cfg.get('server.args');
  const args = Array.isArray(extraArgs) ? extraArgs.map(String) : [];
  args.push('-server', String(port));

  const cwd = getCwd(cfg);
  const useShell = !!cfg.get('server.useShell');
  const showOutputOnStart = cfg.get('server.showOutputOnStart');

  output.appendLine(`[ICS] Starting server…`);
  output.appendLine(`[ICS] Executable: ${exe}`);
  output.appendLine(`[ICS] Args: ${args.join(' ')}`);
  if (cwd) output.appendLine(`[ICS] CWD: ${cwd}`);
  output.appendLine(`[ICS] shell: ${useShell}`);

  try {
    serverProcess = cp.spawn(exe, args, {
      cwd,
      shell: useShell,
      windowsHide: true
    });
  } catch (err) {
    serverProcess = undefined;
    output.appendLine(`[ICS] Failed to spawn process: ${String(err)}`);
    vscode.window.showErrorMessage(`Failed to start ICS server: ${String(err)}`);
    setStatusStopped();
    return;
  }

  currentPort = port;
  setStatusRunning(port);

  serverProcess.on('error', (err) => {
    output?.appendLine(`[ICS] Process error: ${String(err)}`);
    vscode.window.showErrorMessage(`ICS server error: ${String(err)}`);
    currentPort = undefined;
    serverProcess = undefined;
    setStatusStopped();
  });

  serverProcess.on('exit', (code, signal) => {
    output?.appendLine(`[ICS] Server exited (code=${code}, signal=${signal}).`);
    currentPort = undefined;
    serverProcess = undefined;
    setStatusStopped();
  });

  if (serverProcess.stdout) {
    serverProcess.stdout.on('data', (data) => {
      output?.append(data.toString());
    });
  }

  if (serverProcess.stderr) {
    serverProcess.stderr.on('data', (data) => {
      output?.append(data.toString());
    });
  }

  if (showOutputOnStart !== false) {
    output.show(true);
  }

  vscode.window.showInformationMessage(`ICS server started on port ${port}.`);
}

/**
 * @param {boolean} silent
 */
function stopServer(silent = false) {
  if (!serverProcess || serverProcess.killed) {
    if (!silent) vscode.window.showInformationMessage('ICS server is not running.');
    setStatusStopped();
    currentPort = undefined;
    serverProcess = undefined;
    return;
  }

  try {
    output?.appendLine('[ICS] Stopping server…');
    // Try a graceful termination.
    serverProcess.kill();
  } catch (err) {
    output?.appendLine(`[ICS] Failed to stop server: ${String(err)}`);
  }

  // We rely on the 'exit' handler to update UI, but also set immediate state.
  if (!silent) vscode.window.showInformationMessage('ICS server stop requested.');
}

/**
 * VS Code calls this when activating the extension.
 * @param {vscode.ExtensionContext} context
 */
function activate(context) {
  ensureUI(context);

  context.subscriptions.push(
    vscode.commands.registerCommand('ics.startServer', () => startServer(context)),
    vscode.commands.registerCommand('ics.stopServer', () => stopServer(false)),
    vscode.commands.registerCommand('ics.restartServer', async () => {
      stopServer(true);
      await startServer(context);
    })
  );

  // Auto-start (only if enabled)
  const cfg = vscode.workspace.getConfiguration('ics');
  const autoStart = cfg.get('server.autoStart');
  if (autoStart === true) {
    startServer(context).catch((err) => {
      output?.appendLine(`[ICS] Auto-start failed: ${String(err)}`);
    });
  }
}

function deactivate() {
  stopServer(true);
}

module.exports = {
  activate,
  deactivate
};
