# ICS Language Support (VS Code)

This is a minimal VS Code extension for **ICS 2.x (Integrated Canonizer and Solver)**.

It provides:

- **Syntax highlighting** for `.ics` files (keywords/comments as in `ics-mode.el`)
- Commands to **start/stop ICS in server mode** (`ics -server <port>`)

## Features

### Syntax highlighting

Mirrors the Emacs `ics-mode.el` font-lock rules:

- Line comments start with `%`
- Command keywords (case-insensitive):
  `assert, can, sigma, cnstrnt, diseq, solve, ctxt, partition, solution, show, forget, reset, find, inv, verbose, def, type, sig, save, restore, remove, symtab, help`
- Built-ins (case-insensitive): `true, false, int, real`

### Start ICS as a server

ICS supports a TCP server mode via the `-server` flag.

Use the Command Palette:

- **ICS: Start Server**
- **ICS: Stop Server**
- **ICS: Restart Server**

Server output is written to the **"ICS Server"** Output panel.

## Requirements

- An **ICS executable** available on your PATH (e.g. `ics`) *or* set an absolute path in settings.

ICS itself is not bundled by this extension.

## Configuration

Open VS Code settings and search for **ICS**:

- `ics.executablePath` (default: `ics`)
- `ics.server.port` (default: `8123`)
- `ics.server.args` (default: `[]`)
- `ics.server.cwd` (default: `null`)
- `ics.server.useShell` (default: `false`)
- `ics.server.autoStart` (default: `false`)
- `ics.server.showOutputOnStart` (default: `true`)

### Example settings

```json
{
  "ics.executablePath": "/usr/local/bin/ics",
  "ics.server.port": 8123,
  "ics.server.args": ["-pp", "prefix"],
  "ics.server.autoStart": false
}
```

## Installing locally

1. Copy this folder into your VS Code extensions directory, e.g.

   - macOS/Linux: `~/.vscode/extensions/ics-language-support`
   - Windows: `%USERPROFILE%\.vscode\extensions\ics-language-support`

2. Reload VS Code.

(Optionally, package into a `.vsix` with `vsce package` if you have the VSCE tooling installed.)

## License

The extension code is MIT.

ICS itself is distributed separately under the ICS Community Research License.
